def my_function(arg1, arg2):
  """
  This is a simple function that takes two arguments and returns their sum.
  """
  return arg1 + arg2
